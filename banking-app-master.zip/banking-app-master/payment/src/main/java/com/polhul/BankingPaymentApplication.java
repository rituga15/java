package com.polhul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by TPolhul on 3/16/2018.
 */
@SpringBootApplication
public class BankingPaymentApplication {

    public static void main(String[] args) {
        SpringApplication.run(BankingPaymentApplication.class, args);
    }
}
