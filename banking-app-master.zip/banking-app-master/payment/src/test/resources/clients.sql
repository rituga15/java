INSERT INTO client (id, email, password) VALUES (1, 'Email@1', 'password@1');
INSERT INTO client (id, email, password) VALUES (1, 'Email@2', 'password@2');